<html>
<head>
   
</head>
<style>
 
 
</style>

<h1> Laravel One to Many Example </h1>

<h3> All Posts </h3>

@foreach ($allposts as $post)
<li> 
 
    {{ $post->post_name}}  
 
    </a>
 
</li>
@endforeach

<h3> All Comments </h3>

@foreach ($allcomments as $comment)
<li> 
 
    {{ $comment->comment}}  
 
    </a>
 
</li>
@endforeach

<h3> Below are comments from Laravel Post whose id is 1 </h3>
@foreach ($commentsFirst as $comment)
<li> 
 
    {{ $comment->comment}}  
 
    </a>
 
</li>
@endforeach


<h3> Below are comments from Android Post whose id is 2 </h3>


@foreach ($commentsSecond as $comment)
<li> 
 
    {{ $comment->comment}}  
 
    </a>
 
</li>
@endforeach

</body>
</html>