<?php

namespace App\Http\Controllers;

use App\Post;
use App\Comment;
use Illuminate\Http\Request;

class CommentsController extends Controller
{
    //
    public function commentPost()
    {
 
        $postFirst = Post::find(1);
        $commentsFirst = $postFirst->comments;
      
        $postSecond = Post::find(2);
        $commentsSecond = $postSecond->comments;

        $allposts = Post::all();
        $allcomments = Comment::all();
     
        return view('index',compact('commentsFirst','commentsSecond','allposts','allcomments'));
       
    }
}
