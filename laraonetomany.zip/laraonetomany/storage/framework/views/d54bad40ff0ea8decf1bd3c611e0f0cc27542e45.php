<html>
<head>
   
</head>
<style>
 
 
</style>

<h1> Laravel One to Many Example </h1>

<h3> All Posts </h3>

<?php $__currentLoopData = $allposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($post->post_name); ?>  
 
    </a>
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h3> All Comments </h3>

<?php $__currentLoopData = $allcomments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($comment->comment); ?>  
 
    </a>
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h3> Below are comments from Laravel Post whose id is 1 </h3>
<?php $__currentLoopData = $commentsFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($comment->comment); ?>  
 
    </a>
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<h3> Below are comments from Android Post whose id is 2 </h3>


<?php $__currentLoopData = $commentsSecond; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($comment->comment); ?>  
 
    </a>
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH /Users/hardikparsania_mac/Desktop/web_demonuts/laraOnetoMany/laraonetomany/resources/views/index.blade.php ENDPATH**/ ?>